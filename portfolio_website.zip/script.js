document.addEventListener('DOMContentLoaded', () => {
  console.log("Portfolio Loaded");
});
